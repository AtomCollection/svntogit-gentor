# GenTor
GenTor - Make your internet traffic anonymized through Tor network.

# Installing GenTor

    git clone https://github.com/AtomCollection/GenTor
    cd GenTor
    sudo python3 install.py

# Quick start
To get started, simply execute gentor and follow the instructions:
    
    sudo gentor

# Help
    OPTIONS:
      -h, --help            show this help message and exit
      -p, --privoxy         Connecting to Tor with Privoxy - Enhance your privacy
      -s, --start           Start connecting to Tor
      -x, --stop            Stop connecting to Tor
      -r, --renew           Renew the current Tor circuit
      -id COUNTRY ISO CODE  Connect to Tor exit node of a specific country
      -mac INTERFACE        Randomly change MAC address
      -c, --checkip         Check your current IPv4 address
      --dns                 Use this to fix DNS
      --nodelay             Disable delay time
      -e, --enable          Enable anonymization at boot time
      -d, --disable         Enable anonymization at boot time
      -u, --uninstall       Uninstall GenTor
