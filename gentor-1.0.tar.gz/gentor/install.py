#!/usr/bin/python3

from torngconf.theme import *
from time import sleep
from os import system, path, name    
import uuid as geteuid

def check_windows():
    if name == "nt":
        print(English.sorry_windows)
        exit()
    

language = English

check_windows()

print(color.GREEN + """
   OOOOO           OO                           OOOOO          O       
       O            O                               O          O       
      O             O                              O           O       
     O     OOOO     O     OOOO         O O OO     O     OOOO   O   O   
     O         O    O         O        OO O  O   OOO        O  O  O    
    O      OOOOO    O     OOOOO        O  O  O      O   OOOOO  OOO     
    O     O    O    O    O    O        O  O  O      O  O    O  O  O    
   O      O   OO    O    O   OO        O  O  O  O   O  O   OO  O   O   
   O       OOO O  OOOOO   OOO O        O  O  O   OOO    OOO O  O    O  
""")


if path.isfile('/usr/bin/pacman') == True:
    INSTALL_PACKAGES = "pacman -S "
        
elif path.isfile('/usr/bin/apt') == True:
    INSTALL_PACKAGES = "apt install "
    
elif path.isfile('/usr/bin/dnf') == True:
    INSTALL_PACKAGES = "dnf install "
        
elif path.isfile('/usr/bin/yum') == True:
    INSTALL_PACKAGES = "yum install "
        
elif path.isfile('/usr/bin/zypper') == True:
    INSTALL_PACKAGES = "zypper install "
        
elif path.isfile('/usr/bin/xbps-install') == True:
    INSTALL_PACKAGES = "xbps-install -S "
        
elif path.isfile('/usr/bin/upgradepkg') == True:
    INSTALL_PACKAGES = "upgradepkg --install-new "

else:
    print(language.sorry_some_os)
    exit()


def install_package(package):
    try:
        if path.isfile('/usr/bin/'+package) == True:
            print(language.already_installed.format(package))
            
        else:
            print(language.installing.format(package))
            
            if path.isfile('/usr/bin/upgradepkg') == True:
                print(language.downloading.format(package))

                if package == 'tor':
                    system('wget https://slack.conraid.net/repository/slackware64-current/tor/tor-0.4.2.7-x86_64-1cf.txz')
                    system(INSTALL_PACKAGES + 'tor-0.4.2.7-x86_64-1cf.txz')
                    
                elif package == 'macchanger':
                    system('wget https://slack.conraid.net/repository/slackware64-current/macchanger/macchanger-1.7.0-x86_64-5cf.txz')
                    system(INSTALL_PACKAGES + 'macchanger-1.7.0-x86_64-5cf.txz')
                    
                elif package == 'curl':
                    system('wget http://slackware.cs.utah.edu/pub/slackware/slackware64-14.2/patches/packages/curl-7.72.0-x86_64-1_slack14.2.txz')
                    system(INSTALL_PACKAGES + '--install-new curl-7.72.0-x86_64-1_slack14.2.txz')
                    
                elif package == 'privoxy':
                    system('wget https://packages.slackonly.com/pub/packages/14.2-x86_64/network/privoxy/privoxy-3.0.28-x86_64-1_slonly.txz')
                    system(INSTALL_PACKAGES + 'privoxy-3.0.28-x86_64-1_slonly.txz')
                    
                elif package == 'netstat':
                    system('wget http://slackware.cs.utah.edu/pub/slackware/slackware64-current/slackware64/n/net-tools-20181103_0eebece-x86_64-1.txz')
                    system(INSTALL_PACKAGES + 'net-tools-20181103_0eebece-x86_64-1.txz')
                
            else:
                if package == 'netstat': package = 'net-tools'

                system(INSTALL_PACKAGES + package)

            print(icon.success + language.done)
            print(language.installed.format(package))
            
            if path.isfile('/usr/bin/upgradepkg') == True:
                print(language.torghostng_tip.format('python3 gentor.py'))
                exit()
            
    except KeyboardInterrupt:
        print()
        exit()


def install_gentor():
    try:
        print(language.installing.format('GenTor'))
        system('cp -r gentor.py /usr/bin')
        system('cp -r torngconf /usr/bin')
        system('cp gentor-autostart.service /etc/systemd/system')
        system('systemctl daemon-reload')
        system('mv /usr/bin/gentor.py /usr/bin/gentor')
        system('chmod +x /usr/bin/gentor')
        
        print(icon.success + language.done)
        print(language.torghostng_tip.format('gentor') + color.END)
        
    except KeyboardInterrupt:
        print()
        exit()


packages = ['tor','macchanger','privoxy','netstat','curl']
for package in packages:
    install_package(package)

install_gentor()
exit()